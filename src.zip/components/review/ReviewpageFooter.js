import React from "react";

function ReviewpageFooter(){

  return(
    <>
      <div style={{display: "flex", justifyContent:"center", alignItems:"center", marginTop:"1rem", border:"2px solid #D6E4E5", borderRadius:"15px", marginLeft:"1rem", marginRight:"1rem", padding:"15px 0", backgroundColor:"#fff"}}>
        <p>Footer</p>
      </div>
    </>
  )
}

export default ReviewpageFooter;